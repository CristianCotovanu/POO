package grandmagician;

public interface IObserver {
    void update(ObserverInformation observerInformation);
}
