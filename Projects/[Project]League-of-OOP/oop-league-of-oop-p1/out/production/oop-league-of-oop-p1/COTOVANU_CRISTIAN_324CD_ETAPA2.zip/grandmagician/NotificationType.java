package grandmagician;

public enum NotificationType {
    PlayerKill, AngelSpawn, AngelKill, AngelHit, AngelHelp, AngelRevive, LevelUp
}
