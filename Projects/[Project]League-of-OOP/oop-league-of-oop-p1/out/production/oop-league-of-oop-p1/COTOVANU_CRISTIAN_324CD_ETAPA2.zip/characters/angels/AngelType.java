package characters.angels;

public enum AngelType {
    DamageAngel, DarkAngel, Dracula, GoodBoy, LevelUpAngel,
    LifeGiver, SmallAngel, Spawner, TheDoomer, XPAngel
}
