package heroes;

import skills.IHeroVisitor;

import static heroes.HeroConstants.KNIGHT_HP_LVL_UP;
import static heroes.HeroConstants.KNIGHT_INITIAL_HP;
import static heroes.HeroConstants.KNIGHT_RACE;

public final class Knight extends Hero {
    Knight() {
        super();
        this.race = KNIGHT_RACE;
        this.currentHp = KNIGHT_INITIAL_HP;
        this.maxHp = KNIGHT_INITIAL_HP;
    }

    protected void healUp(final int currentLevel) {
        currentHp = KNIGHT_INITIAL_HP + currentLevel * KNIGHT_HP_LVL_UP;
        maxHp = currentHp;
    }

    public void acceptSkill(final IHeroVisitor skill) {
        skill.applyEffect(this);
    }
}
