package heroes;

import skills.effects.DamageOverTime;
import skills.effects.Stun;

import static heroes.HeroConstants.XP_NEEDED_AFTER_FIRST;
import static heroes.HeroConstants.XP_NEEDED_FIRST_TRANSITION;

public abstract class Hero implements ISkillVisitable {
    protected String race;
    protected int maxHp;
    protected int currentHp;
    protected int currentXp;
    protected int level;
    protected int posX;
    protected int posY;
    protected DamageOverTime damageOverTime;
    protected Stun stun;


    public Hero() {
        level = HeroConstants.INITIAL_LVL;
        currentXp = HeroConstants.INITIAL_XP;
        stun = new Stun();
        damageOverTime = new DamageOverTime();
    }

    public final boolean isDead() {
        return currentHp <= 0;
    }

    public final boolean isStunned() {
        return stun.getRounds() > 0;
    }

    protected abstract void healUp(int currentLevel);

    public final void addExperiencePoints(final int expPoints) {
        currentXp += expPoints;
        int levelReached = (currentXp - XP_NEEDED_FIRST_TRANSITION) / XP_NEEDED_AFTER_FIRST + 1;

        if (levelReached > level) {
            level = levelReached;
            if (!isDead()) {
                healUp(level);
            }
        }
    }

    public final String getRace() {
        return race;
    }

    public final int getMaxHp() {
        return maxHp;
    }

    public final int getCurrentHp() {
        return currentHp;
    }

    public final void setCurrentHp(final int currentHp) {
        this.currentHp = currentHp;
    }

    public final int getCurrentXp() {
        return currentXp;
    }

    public final int getLevel() {
        return level;
    }

    public final DamageOverTime getDamageOverTime() {
        return damageOverTime;
    }

    public final void setDamageOverTime(final DamageOverTime damageOverTime) {
        this.damageOverTime = damageOverTime;
    }

    public final Stun getStun() {
        return stun;
    }

    public final void setStun(final Stun stun) {
        this.stun = stun;
    }

    public final int getPosX() {
        return posX;
    }

    public final void setPosX(final int posX) {
        this.posX = posX;
    }

    public final int getPosY() {
        return posY;
    }

    public final void setPosY(final int posY) {
        this.posY = posY;
    }
}
