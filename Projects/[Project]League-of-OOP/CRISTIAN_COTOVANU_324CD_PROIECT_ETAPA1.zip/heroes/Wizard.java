package heroes;

import skills.IHeroVisitor;

import static heroes.HeroConstants.WIZARD_HP_LVL_UP;
import static heroes.HeroConstants.WIZARD_INITIAL_HP;
import static heroes.HeroConstants.WIZARD_RACE;

public final class Wizard extends Hero {
    Wizard() {
        super();
        this.race = WIZARD_RACE;
        this.currentHp = WIZARD_INITIAL_HP;
        this.maxHp = WIZARD_INITIAL_HP;
    }

    protected void healUp(final int currentLevel) {
        currentHp = WIZARD_INITIAL_HP + currentLevel * WIZARD_HP_LVL_UP;
        maxHp = currentHp;
    }

    public void acceptSkill(final IHeroVisitor skill) {
        skill.applyEffect(this);
    }
}
