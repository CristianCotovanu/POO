package heroes;

import skills.IHeroVisitor;

import static heroes.HeroConstants.ROGUE_HP_LVL_UP;
import static heroes.HeroConstants.ROGUE_INITIAL_HP;
import static heroes.HeroConstants.ROGUE_RACE;

public final class Rogue extends Hero {
    Rogue() {
        super();
        this.race = ROGUE_RACE;
        this.currentHp = ROGUE_INITIAL_HP;
        this.maxHp = ROGUE_INITIAL_HP;
    }

    protected void healUp(final int currentLevel) {
        currentHp = ROGUE_INITIAL_HP + currentLevel * ROGUE_HP_LVL_UP;
        maxHp = currentHp;
    }

    public void acceptSkill(final IHeroVisitor skill) {
        skill.applyEffect(this);
    }
}
