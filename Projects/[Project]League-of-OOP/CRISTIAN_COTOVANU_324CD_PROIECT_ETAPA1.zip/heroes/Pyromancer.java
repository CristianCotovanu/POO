package heroes;

import skills.IHeroVisitor;

import static heroes.HeroConstants.PYROMANCER_HP_LVL_UP;
import static heroes.HeroConstants.PYROMANCER_INITIAL_HP;
import static heroes.HeroConstants.PYROMANCER_RACE;

public final class Pyromancer extends Hero {
    Pyromancer() {
        super();
        this.race = PYROMANCER_RACE;
        this.currentHp = PYROMANCER_INITIAL_HP;
        this.maxHp = PYROMANCER_INITIAL_HP;
    }

    protected void healUp(final int currentLevel) {
        currentHp = PYROMANCER_INITIAL_HP + currentLevel * PYROMANCER_HP_LVL_UP;
        maxHp = currentHp;
    }

    @Override
    public void acceptSkill(final IHeroVisitor skill) {
        skill.applyEffect(this);
    }
}
