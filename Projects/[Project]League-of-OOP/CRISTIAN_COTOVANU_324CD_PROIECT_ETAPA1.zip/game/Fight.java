package game;

import heroes.Hero;
import map.Terrain;
import skills.Skill;
import skills.SkillFactory;

import java.util.List;

import static heroes.HeroConstants.OPERAND1_EXP_FORMULA;
import static heroes.HeroConstants.OPERAND2_EXP_FORMULA;

public final class Fight {
    private Hero caster;
    private Hero victim;

    public Fight(final Hero caster, final Hero victim) {
        this.caster = caster;
        this.victim = victim;
    }

    void startFight(final Terrain terrain) {
        SkillFactory skillFactory = SkillFactory.getInstance();
        List<Skill> skills = skillFactory.create(caster, terrain);
        for (Skill skill : skills) {
            victim.acceptSkill(skill);
        }

        skills = skillFactory.create(victim, terrain);

        for (Skill skill : skills) {
            caster.acceptSkill(skill);
        }

        computeXpAfterFight(caster, victim);
        computeXpAfterFight(victim, caster);
    }

    private void computeXpAfterFight(final Hero attacker, final Hero target) {
        if (target.isDead()) {
            attacker.addExperiencePoints(Integer.max(0, OPERAND1_EXP_FORMULA
                            - (attacker.getLevel() - target.getLevel()) * OPERAND2_EXP_FORMULA));
        }
    }
}
