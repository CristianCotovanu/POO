package game;

import fileio.GameInput;
import heroes.Hero;
import heroes.HeroFactory;
import map.GameMap;
import map.MoveHero;
import map.Terrain;
import skills.effects.DamageOverTime;
import skills.effects.Stun;

import java.util.ArrayList;
import java.util.List;

public final class GameEngine {
    private GameMap map;
    private List<Hero> heroesList;
    private static int roundNumber;
    private MoveHero moveHero;

    public GameEngine(final GameInput gameInput) {
        heroesList = new ArrayList<>();
        instantiatePlayers(gameInput.getPlayerRaceAndPosition());
        map = GameMap.getInstance(gameInput.getLandTypesPerRow(), gameInput.getMapRows(),
                gameInput.getMapCols(), heroesList);
        moveHero = new MoveHero(map.getBattlefield(), heroesList, gameInput.getMovesForRound());
    }

    public void start() {
        for (String roundMove : moveHero.getMovesThisGame()) {
            moveHero.moveHeroesPerRound(roundMove);
            applyStunToHeroes(heroesList);
            Terrain[][] battlefield = map.getBattlefield();

            for (Terrain[] terrains : battlefield) {
                for (Terrain terrain : terrains) {
                    ArrayList<Hero> heroesOnTile = terrain.getHeroesOnTerrain();

                    for (Hero hero : heroesOnTile) {
                        applyDoT(hero);
                    }

                    eliminateDeadPlayersFromMap(map.getBattlefield());

                    for (int ii = 0; ii < heroesOnTile.size(); ii++) {
                        for (int jj = ii; jj < heroesOnTile.size(); jj++) {
                            if (ii != jj) {
                                Fight fight = new Fight(heroesOnTile.get(ii), heroesOnTile.get(jj));
                                fight.startFight(terrain);
                            }
                        }
                    }
                }
            }
            roundNumber++;
            eliminateDeadPlayersFromMap(map.getBattlefield());
        }
    }

    private void eliminateDeadPlayersFromMap(final Terrain[][] battlefield) {
        for (Terrain[] terrains : battlefield) {
            for (Terrain terrain : terrains) {
                ArrayList<Hero> heroesOnTerrain = terrain.getHeroesOnTerrain();
                heroesOnTerrain.removeIf(Hero::isDead);
            }
        }
    }

    private void applyDoT(final Hero hero) {
        DamageOverTime damageOverTime = hero.getDamageOverTime();
        if (damageOverTime.getRounds() > 0) {
            damageOverTime.setRounds(damageOverTime.getRounds() - 1);
            hero.setCurrentHp(hero.getCurrentHp() - Math.round(damageOverTime.getDamagePerRound()));
        }
    }

    private void applyStunToHeroes(final List<Hero> heroes) {
        for (Hero hero : heroes) {
            Stun stun = hero.getStun();
            if (stun.getRounds() > 0) {
                stun.setRounds(stun.getRounds() - 1);
            }
        }
    }

    private void instantiatePlayers(final List<String> playersRaceAndPosition) {
        HeroFactory heroFactory = HeroFactory.getInstance();
        for (String string : playersRaceAndPosition) {
            String[] tokens = string.split(" ");

            Hero newHero = heroFactory.create(tokens[0]);
            int coordX = Integer.parseInt(tokens[1]);
            int coordY = Integer.parseInt(tokens[2]);

            newHero.setPosX(coordX);
            newHero.setPosY(coordY);

            heroesList.add(newHero);
        }
    }

    public List<Hero> getHeroesList() {
        return heroesList;
    }

    public static int getRoundNumber() {
        return roundNumber;
    }
}
