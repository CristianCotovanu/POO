package fileio;

import heroes.Hero;

import java.io.IOException;
import java.util.List;

public final class WriteFile {
    private final String inputPath;
    private final String outputPath;

    public WriteFile(final String inputPath, final String outputPath) {
        this.inputPath = inputPath;
        this.outputPath = outputPath;
    }

    public void writeLeaderboard(final List<Hero> heroes) {
        try {
            FileSystem fileSystem = new FileSystem(inputPath, outputPath);

            for (Hero hero : heroes) {
                fileSystem.writeWord(hero.getRace());
                fileSystem.writeWord(" ");

                if (hero.isDead()) {
                    fileSystem.writeWord("dead");
                    fileSystem.writeWord("\n");
                } else {
                    fileSystem.writeInt(hero.getLevel());
                    fileSystem.writeWord(" ");
                    fileSystem.writeInt(hero.getCurrentXp());
                    fileSystem.writeWord(" ");
                    fileSystem.writeInt(hero.getCurrentHp());
                    fileSystem.writeWord(" ");
                    fileSystem.writeInt(hero.getPosX());
                    fileSystem.writeWord(" ");
                    fileSystem.writeInt(hero.getPosY());
                    fileSystem.writeWord("\n");
                }
            }
            fileSystem.writeNewLine();
            fileSystem.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
