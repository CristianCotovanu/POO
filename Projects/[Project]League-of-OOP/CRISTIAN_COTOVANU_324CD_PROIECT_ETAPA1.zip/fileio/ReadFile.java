package fileio;

import java.util.ArrayList;
import java.util.List;

public final class ReadFile {
    private final String inputPath;
    private final String outputPath;

    public ReadFile(final String inputPath, final String outputPath) {
        this.inputPath = inputPath;
        this.outputPath = outputPath;
    }

    public GameInput load() {
        List<String> playerRaceAndPosition = new ArrayList<>();
        List<String> landTypesPerRow = new ArrayList<>();
        List<String> movesForRound = new ArrayList<>();
        int mapCols = 0;
        int mapRows = 0;
        int playersNr;
        int roundsNr;

        try {
            FileSystem fileSystem = new FileSystem(inputPath, outputPath);

            mapRows = fileSystem.nextInt();
            mapCols = fileSystem.nextInt();

            for (int i = 0; i < mapRows; i++) {
                landTypesPerRow.add(fileSystem.nextWord());
            }

            playersNr = fileSystem.nextInt();

            for (int i = 0; i < playersNr; i++) {
                playerRaceAndPosition.add(fileSystem.nextWord() + " "
                        + fileSystem.nextWord() + " " + fileSystem.nextWord());
            }

            roundsNr = fileSystem.nextInt();

            for (int i = 0; i < roundsNr; i++) {
                movesForRound.add(fileSystem.nextWord());
            }

            fileSystem.close();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        return new GameInput(mapCols, mapRows,
                landTypesPerRow, playerRaceAndPosition, movesForRound);
    }
}
