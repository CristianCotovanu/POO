package skills;

import heroes.Knight;
import heroes.Pyromancer;
import heroes.Rogue;
import heroes.Wizard;


public interface IHeroVisitor {
    void applyEffect(Pyromancer pyromancer);

    void applyEffect(Knight knight);

    void applyEffect(Rogue rogue);

    void applyEffect(Wizard wizard);
}

