package skills.knight;

import heroes.Hero;
import heroes.Knight;
import heroes.Pyromancer;
import heroes.Rogue;
import heroes.Wizard;
import map.Desert;
import map.Land;
import map.Volcanic;
import map.Woods;
import map.Terrain;
import skills.Skill;
import skills.effects.DamageOverTime;
import skills.effects.Stun;

import static skills.knight.KnightConstants.SLAM_DMG_LVL_UP;;
import static skills.knight.KnightConstants.SLAM_INITIAL_DMG;
import static skills.knight.KnightConstants.SLAM_VS_KNIGHT;
import static skills.knight.KnightConstants.SLAM_VS_PYROMANCER;
import static skills.knight.KnightConstants.SLAM_VS_WIZARD;
import static skills.knight.KnightConstants.SLAM_VS_ROGUE;
import static skills.knight.KnightConstants.KNIGHT_LAND_BONUS;
import static skills.knight.KnightConstants.SLAM_STUN_DURATION;

public final class Slam extends Skill {

    public Slam(final Hero caster, final Terrain terrain) {
        super(caster, terrain, SLAM_INITIAL_DMG);
    }

    @Override
    public void applyEffect(final Pyromancer pyromancer) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + SLAM_VS_PYROMANCER;

        pyromancer.setCurrentHp(pyromancer.getCurrentHp() - Math.round((this.damage
                + SLAM_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));

        pyromancer.setStun(new Stun(SLAM_STUN_DURATION));
        pyromancer.setDamageOverTime(new DamageOverTime(0, 0));
    }

    @Override
    public void applyEffect(final Knight knight) {
        float terrainModifier = 1f + terrain.acceptSkill(this);
        float raceModifier = 1f + SLAM_VS_KNIGHT;

        knight.setCurrentHp(knight.getCurrentHp() - Math.round((this.damage
                + SLAM_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));

        knight.setStun(new Stun(SLAM_STUN_DURATION));
        knight.setDamageOverTime(new DamageOverTime(0, 0));
    }

    @Override
    public void applyEffect(final Rogue rogue) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + SLAM_VS_ROGUE;

        rogue.setCurrentHp(rogue.getCurrentHp() - Math.round((this.damage
                + SLAM_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));

        rogue.setStun(new Stun(SLAM_STUN_DURATION));
        rogue.setDamageOverTime(new DamageOverTime(0, 0));
    }

    @Override
    public void applyEffect(final Wizard wizard) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + SLAM_VS_WIZARD;

        wizard.setCurrentHp(wizard.getCurrentHp() - Math.round((this.damage
                + SLAM_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));

        wizard.setStun(new Stun(SLAM_STUN_DURATION));
        wizard.setDamageOverTime(new DamageOverTime(0, 0));
    }

    @Override
    public float visitTerrain(final Volcanic volcanic) {
        return 0;
    }

    @Override
    public float visitTerrain(final Land land) {
        return KNIGHT_LAND_BONUS;
    }

    @Override
    public float visitTerrain(final Woods woods) {
        return 0;
    }

    @Override
    public float visitTerrain(final Desert desert) {
        return 0;
    }
}
