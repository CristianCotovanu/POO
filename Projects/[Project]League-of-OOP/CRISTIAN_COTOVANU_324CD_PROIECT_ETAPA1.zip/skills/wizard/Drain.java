package skills.wizard;

import heroes.Hero;
import heroes.Knight;
import heroes.Pyromancer;
import heroes.Rogue;
import heroes.Wizard;
import map.Desert;
import map.Land;
import map.Volcanic;
import map.Woods;
import map.Terrain;
import skills.Skill;

import static skills.wizard.WizardConstants.WIZARD_DRAIN_FORMULA_OPERAND;

public final class Drain extends Skill {
    public Drain(final Hero caster, final Terrain terrain) {
        super(caster, terrain, 0);
    }

    @Override
    public void applyEffect(final Pyromancer pyromancer) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + WizardConstants.DRAIN_VS_PYROMANCER;

        float heroHp = Math.min(WIZARD_DRAIN_FORMULA_OPERAND
                * pyromancer.getMaxHp(), pyromancer.getCurrentHp());
        float percentage = (WizardConstants.DRAIN_INITIAL_PERCENTAGE + caster.getLevel()
                        * WizardConstants.DRAIN_PERCENTAGE_LVL_UP)
                        * terrainModifier * raceModifier;

        pyromancer.setCurrentHp(pyromancer.getCurrentHp() - Math.round(heroHp * percentage));
    }

    @Override
    public void applyEffect(final Knight knight) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + WizardConstants.DRAIN_VS_KNIGHT;

        float heroHp = Math.min(WIZARD_DRAIN_FORMULA_OPERAND
                * knight.getMaxHp(), knight.getCurrentHp());
        float percentage = (WizardConstants.DRAIN_INITIAL_PERCENTAGE + caster.getLevel()
                * WizardConstants.DRAIN_PERCENTAGE_LVL_UP)
                * terrainModifier * raceModifier;

        knight.setCurrentHp(knight.getCurrentHp() - Math.round(heroHp * percentage));
    }

    @Override
    public void applyEffect(final Rogue rogue) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + WizardConstants.DRAIN_VS_ROGUE;

        float heroHp = Math.min(WIZARD_DRAIN_FORMULA_OPERAND
                * rogue.getMaxHp(), rogue.getCurrentHp());
        float percentage = (WizardConstants.DRAIN_INITIAL_PERCENTAGE + caster.getLevel()
                * WizardConstants.DRAIN_PERCENTAGE_LVL_UP)
                * terrainModifier * raceModifier;

        rogue.setCurrentHp(rogue.getCurrentHp() - Math.round(heroHp * percentage));
    }

    @Override
    public void applyEffect(final Wizard wizard) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + WizardConstants.DRAIN_VS_WIZARD;

        float heroHp = Math.min(WIZARD_DRAIN_FORMULA_OPERAND
                * wizard.getMaxHp(), wizard.getCurrentHp());
        float percentage = (WizardConstants.DRAIN_INITIAL_PERCENTAGE + caster.getLevel()
                * WizardConstants.DRAIN_PERCENTAGE_LVL_UP)
                * terrainModifier * raceModifier;

        wizard.setCurrentHp(wizard.getCurrentHp() - Math.round(heroHp * percentage));
    }

    @Override
    public float visitTerrain(final Volcanic volcanic) {
        return 0;
    }

    @Override
    public float visitTerrain(final Land land) {
        return 0;
    }

    @Override
    public float visitTerrain(final Woods woods) {
        return 0;
    }

    @Override
    public float visitTerrain(final Desert desert) {
        return WizardConstants.WIZARD_DESERT_BONUS;
    }
}
