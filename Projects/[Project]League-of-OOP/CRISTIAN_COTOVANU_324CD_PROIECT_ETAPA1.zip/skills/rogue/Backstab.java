package skills.rogue;

import game.GameEngine;
import heroes.Hero;
import heroes.Knight;
import heroes.Pyromancer;
import heroes.Rogue;
import heroes.Wizard;
import map.Desert;
import map.Land;
import map.Volcanic;
import map.Woods;
import map.Terrain;
import skills.Skill;

import static skills.rogue.RogueConstants.BACKSTAB_DMG_LVL_UP;
import static skills.rogue.RogueConstants.BACKSTAB_INITIAL_DMG;
import static skills.rogue.RogueConstants.BACKSTAB_VS_PYROMANCER;
import static skills.rogue.RogueConstants.BACKSTAB_VS_ROGUE;
import static skills.rogue.RogueConstants.BACKSTAB_VS_KNIGHT;
import static skills.rogue.RogueConstants.BACKSTAB_VS_WIZARD;
import static skills.rogue.RogueConstants.LUCKY_CRIT_ROUND;
import static skills.rogue.RogueConstants.ROGUE_CRIT_BONUS;
import static skills.rogue.RogueConstants.ROGUE_WOODS_BONUS;

public final class Backstab extends Skill {
    public Backstab(final Hero caster, final Terrain terrain) {
        super(caster, terrain, BACKSTAB_INITIAL_DMG);
    }

    @Override
    public void applyEffect(final Pyromancer pyromancer) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + BACKSTAB_VS_PYROMANCER;

        if (terrainModifier != 1 && GameEngine.getRoundNumber() % LUCKY_CRIT_ROUND == 0) {
            pyromancer.setCurrentHp(pyromancer.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier
                    * raceModifier * ROGUE_CRIT_BONUS));
        } else if (terrainModifier != 1) {
            pyromancer.setCurrentHp(pyromancer.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
        } else {
            pyromancer.setCurrentHp(pyromancer.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
        }
    }

    @Override
    public void applyEffect(final Knight knight) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + BACKSTAB_VS_KNIGHT;

        if (terrainModifier != 1 && GameEngine.getRoundNumber() % LUCKY_CRIT_ROUND == 0) {
            knight.setCurrentHp(knight.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier
                    * raceModifier * ROGUE_CRIT_BONUS));
        } else if (terrainModifier != 1) {
            knight.setCurrentHp(knight.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
        } else {
            knight.setCurrentHp(knight.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
        }
    }

    @Override
    public void applyEffect(final Rogue rogue) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + BACKSTAB_VS_ROGUE;

        if (terrainModifier != 1 && GameEngine.getRoundNumber() % LUCKY_CRIT_ROUND == 0) {
            rogue.setCurrentHp(rogue.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier
                    * raceModifier * ROGUE_CRIT_BONUS));
        } else if (terrainModifier != 1) {
            rogue.setCurrentHp(rogue.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
        } else {
            rogue.setCurrentHp(rogue.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
        }
    }

    @Override
    public void applyEffect(final Wizard wizard) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + BACKSTAB_VS_WIZARD;

        if (terrainModifier != 1 && GameEngine.getRoundNumber() % LUCKY_CRIT_ROUND == 0) {
            wizard.setCurrentHp(wizard.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier
                    * raceModifier * ROGUE_CRIT_BONUS));
        } else if (terrainModifier != 1) {
            wizard.setCurrentHp(wizard.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
        } else {
            wizard.setCurrentHp(wizard.getCurrentHp() - Math.round((this.damage
                    + BACKSTAB_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
        }
    }

    @Override
    public float visitTerrain(final Volcanic volcanic) {
        return 0;
    }

    @Override
    public float visitTerrain(final Land land) {
        return 0;
    }

    @Override
    public float visitTerrain(final Woods woods) {
        return ROGUE_WOODS_BONUS;
    }

    @Override
    public float visitTerrain(final Desert desert) {
        return 0;
    }
}
