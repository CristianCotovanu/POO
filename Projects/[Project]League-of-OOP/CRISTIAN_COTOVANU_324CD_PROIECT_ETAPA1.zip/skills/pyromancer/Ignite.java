package skills.pyromancer;

import heroes.Hero;
import heroes.Knight;
import heroes.Pyromancer;
import heroes.Rogue;
import heroes.Wizard;

import map.Desert;
import map.Land;
import map.Volcanic;
import map.Woods;
import map.Terrain;
import skills.IHeroVisitor;
import skills.Skill;
import skills.effects.DamageOverTime;

import static skills.pyromancer.PyromancerConstants.IGNITE_BASE_DMG_LVL_UP;
import static skills.pyromancer.PyromancerConstants.IGNITE_DMG_PER_ROUND_LVL_UP;
import static skills.pyromancer.PyromancerConstants.IGNITE_INITIAL_DMG_PER_ROUND;
import static skills.pyromancer.PyromancerConstants.IGNITE_ROUNDS_TICK;
import static skills.pyromancer.PyromancerConstants.IGNITE_VS_ROGUE;
import static skills.pyromancer.PyromancerConstants.PYROMANCER_VOLCANIC_BONUS;

public final class Ignite extends Skill implements IHeroVisitor {
    public Ignite(final Hero caster, final Terrain terrain) {
        super(caster, terrain, PyromancerConstants.IGNITE_INITIAL_BASE_DMG);
    }

    @Override
    public void applyEffect(final Pyromancer pyromancer) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + PyromancerConstants.IGNITE_VS_PYROMANCER;

        pyromancer.setCurrentHp(pyromancer.getCurrentHp() - Math.round((this.damage
                + IGNITE_BASE_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));

        DamageOverTime damageOverTime = new DamageOverTime(Math.round(IGNITE_INITIAL_DMG_PER_ROUND
                + IGNITE_DMG_PER_ROUND_LVL_UP * caster.getLevel())
                * terrainModifier * raceModifier, IGNITE_ROUNDS_TICK);

        pyromancer.setDamageOverTime(damageOverTime);
    }

    @Override
    public void applyEffect(final Knight knight) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + PyromancerConstants.IGNITE_VS_KNIGHT;

        knight.setCurrentHp(knight.getCurrentHp() - Math.round((this.damage
                + IGNITE_BASE_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));

        DamageOverTime damageOverTime = new DamageOverTime(Math.round((IGNITE_INITIAL_DMG_PER_ROUND
                + IGNITE_DMG_PER_ROUND_LVL_UP * caster.getLevel())
                * terrainModifier * raceModifier), IGNITE_ROUNDS_TICK);

        knight.setDamageOverTime(damageOverTime);
    }

    @Override
    public void applyEffect(final Rogue rogue) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + IGNITE_VS_ROGUE;

        rogue.setCurrentHp(rogue.getCurrentHp() - Math.round((this.damage
                + IGNITE_BASE_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));

        DamageOverTime damageOverTime = new DamageOverTime(Math.round((IGNITE_INITIAL_DMG_PER_ROUND
                + IGNITE_DMG_PER_ROUND_LVL_UP * caster.getLevel())
                * terrainModifier * raceModifier), IGNITE_ROUNDS_TICK);

        rogue.setDamageOverTime(damageOverTime);
    }

    @Override
    public void applyEffect(final Wizard wizard) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + PyromancerConstants.IGNITE_VS_WIZARD;

        wizard.setCurrentHp(wizard.getCurrentHp() - Math.round((this.damage
                + IGNITE_BASE_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));

        DamageOverTime damageOverTime = new DamageOverTime(IGNITE_INITIAL_DMG_PER_ROUND
                + IGNITE_DMG_PER_ROUND_LVL_UP * caster.getLevel()
                * terrainModifier * raceModifier, IGNITE_ROUNDS_TICK);

        wizard.setDamageOverTime(damageOverTime);
    }

    @Override
    public float visitTerrain(final Volcanic volcanic) {
        return PYROMANCER_VOLCANIC_BONUS;
    }

    @Override
    public float visitTerrain(final Land land) {
        return 0;
    }

    @Override
    public float visitTerrain(final Woods woods) {
        return 0;
    }

    @Override
    public float visitTerrain(final Desert desert) {
        return 0;
    }
}
