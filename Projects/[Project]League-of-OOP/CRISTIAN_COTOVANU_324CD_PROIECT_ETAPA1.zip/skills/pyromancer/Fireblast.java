package skills.pyromancer;

import heroes.Hero;
import heroes.Knight;
import heroes.Pyromancer;
import heroes.Rogue;
import heroes.Wizard;

import map.Desert;
import map.Land;
import map.Volcanic;
import map.Woods;
import map.Terrain;
import skills.Skill;

import static skills.pyromancer.PyromancerConstants.FIREBLAST_DMG_LVL_UP;
import static skills.pyromancer.PyromancerConstants.FIREBLAST_INITIAL_DMG;
import static skills.pyromancer.PyromancerConstants.FIREBLAST_VS_KNIGHT;
import static skills.pyromancer.PyromancerConstants.FIREBLAST_VS_PYROMANCER;
import static skills.pyromancer.PyromancerConstants.FIREBLAST_VS_WIZARD;
import static skills.pyromancer.PyromancerConstants.FIREBLAST_VS_ROGUE;
import static skills.pyromancer.PyromancerConstants.PYROMANCER_VOLCANIC_BONUS;

public final class Fireblast extends Skill {

    public Fireblast(final Hero caster, final Terrain terrain) {
        super(caster, terrain, FIREBLAST_INITIAL_DMG);
    }

    @Override
    public void applyEffect(final Pyromancer pyromancer) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + FIREBLAST_VS_PYROMANCER;

        pyromancer.setCurrentHp(pyromancer.getCurrentHp() - Math.round((this.damage
                + FIREBLAST_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
    }

    @Override
    public void applyEffect(final Knight knight) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + FIREBLAST_VS_KNIGHT;

        knight.setCurrentHp(knight.getCurrentHp() - Math.round((this.damage
                + FIREBLAST_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
    }

    @Override
    public void applyEffect(final Rogue rogue) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + FIREBLAST_VS_ROGUE;

        rogue.setCurrentHp(rogue.getCurrentHp() - Math.round((this.damage
                + FIREBLAST_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
    }

    @Override
    public void applyEffect(final Wizard wizard) {
        float terrainModifier = 1 + terrain.acceptSkill(this);
        float raceModifier = 1 + FIREBLAST_VS_WIZARD;

        wizard.setCurrentHp(wizard.getCurrentHp() - Math.round((this.damage
                + FIREBLAST_DMG_LVL_UP * caster.getLevel()) * terrainModifier * raceModifier));
    }

    @Override
    public float visitTerrain(final Volcanic volcanic) {
        return PYROMANCER_VOLCANIC_BONUS;
    }

    @Override
    public float visitTerrain(final Land land) {
        return 0;
    }

    @Override
    public float visitTerrain(final Woods woods) {
        return 0;
    }

    @Override
    public float visitTerrain(final Desert desert) {
        return 0;
    }
}
