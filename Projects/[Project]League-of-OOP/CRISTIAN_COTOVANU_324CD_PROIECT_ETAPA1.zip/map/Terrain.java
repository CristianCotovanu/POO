package map;

import heroes.Hero;
import skills.ITerrainVisitor;

import java.util.ArrayList;

public abstract class Terrain {
    private ArrayList<Hero> heroesOnTerrain;

    protected Terrain() {
        heroesOnTerrain = new ArrayList<>();
    }

    final void addHero(final Hero hero) {
        heroesOnTerrain.add(hero);
    }

    final void removeHero(final Hero hero) {
        heroesOnTerrain.remove(hero);
    }

    public abstract float acceptSkill(ITerrainVisitor skill);

    public final ArrayList<Hero> getHeroesOnTerrain() {
        return heroesOnTerrain;
    }

}
